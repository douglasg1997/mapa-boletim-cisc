ol.proj.proj4.register(proj4);
//ol.proj.get("EPSG:31982").setExtent([656889.699473, 7161845.121572, 692361.012847, 7196507.203463]);
var wms_layers = [];


        var lyr_GoogleSatellite_0 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_RegioMetropolitanadeCuritiba_1 = new ol.format.GeoJSON();
var features_RegioMetropolitanadeCuritiba_1 = format_RegioMetropolitanadeCuritiba_1.readFeatures(json_RegioMetropolitanadeCuritiba_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_RegioMetropolitanadeCuritiba_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_RegioMetropolitanadeCuritiba_1.addFeatures(features_RegioMetropolitanadeCuritiba_1);
var lyr_RegioMetropolitanadeCuritiba_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_RegioMetropolitanadeCuritiba_1, 
                style: style_RegioMetropolitanadeCuritiba_1,
                popuplayertitle: 'Região Metropolitana de Curitiba',
                interactive: false,
                title: '<img src="styles/legend/RegioMetropolitanadeCuritiba_1.png" /> Região Metropolitana de Curitiba'
            });
var format_SetoresCensitriosdeCuritibaDensidadeHA_2 = new ol.format.GeoJSON();
var features_SetoresCensitriosdeCuritibaDensidadeHA_2 = format_SetoresCensitriosdeCuritibaDensidadeHA_2.readFeatures(json_SetoresCensitriosdeCuritibaDensidadeHA_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_SetoresCensitriosdeCuritibaDensidadeHA_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_SetoresCensitriosdeCuritibaDensidadeHA_2.addFeatures(features_SetoresCensitriosdeCuritibaDensidadeHA_2);
var lyr_SetoresCensitriosdeCuritibaDensidadeHA_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_SetoresCensitriosdeCuritibaDensidadeHA_2, 
                style: style_SetoresCensitriosdeCuritibaDensidadeHA_2,
                popuplayertitle: 'Setores Censitários de Curitiba: Densidade (HA)',
                interactive: true,
    title: 'Setores Censitários de Curitiba: Densidade (HA)<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_0.png" /> 0 - 41<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_1.png" /> 41 - 75<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_2.png" /> 75 - 113<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_3.png" /> 113 - 163<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_4.png" /> 163 - 240<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_5.png" /> 240 - 357<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_6.png" /> 357 - 527<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_7.png" /> 527 - 819<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_8.png" /> 819 - 1417<br />\
    <img src="styles/legend/SetoresCensitriosdeCuritibaDensidadeHA_2_9.png" /> 1417 - 3341<br />' });
var format_SetoresCensitriosdeCuritiba_3 = new ol.format.GeoJSON();
var features_SetoresCensitriosdeCuritiba_3 = format_SetoresCensitriosdeCuritiba_3.readFeatures(json_SetoresCensitriosdeCuritiba_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_SetoresCensitriosdeCuritiba_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_SetoresCensitriosdeCuritiba_3.addFeatures(features_SetoresCensitriosdeCuritiba_3);
var lyr_SetoresCensitriosdeCuritiba_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_SetoresCensitriosdeCuritiba_3, 
                style: style_SetoresCensitriosdeCuritiba_3,
                popuplayertitle: 'Setores Censitários de Curitiba',
                interactive: false,
                title: '<img src="styles/legend/SetoresCensitriosdeCuritiba_3.png" /> Setores Censitários de Curitiba'
            });
var format_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4 = new ol.format.GeoJSON();
var features_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4 = format_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4.readFeatures(json_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4.addFeatures(features_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4);
var lyr_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4, 
                style: style_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4,
                popuplayertitle: 'Áreas de Abrangência - UMS (Unidades Municipais de Saúde)',
                interactive: false,
                title: '<img src="styles/legend/reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4.png" /> Áreas de Abrangência - UMS (Unidades Municipais de Saúde)'
            });
var format_UnidadesdeProntoAtendimentoUPA_5 = new ol.format.GeoJSON();
var features_UnidadesdeProntoAtendimentoUPA_5 = format_UnidadesdeProntoAtendimentoUPA_5.readFeatures(json_UnidadesdeProntoAtendimentoUPA_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_UnidadesdeProntoAtendimentoUPA_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_UnidadesdeProntoAtendimentoUPA_5.addFeatures(features_UnidadesdeProntoAtendimentoUPA_5);
var lyr_UnidadesdeProntoAtendimentoUPA_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_UnidadesdeProntoAtendimentoUPA_5, 
                style: style_UnidadesdeProntoAtendimentoUPA_5,
                popuplayertitle: 'Unidades de Pronto Atendimento (UPA)',
                interactive: true,
                title: '<img src="styles/legend/UnidadesdeProntoAtendimentoUPA_5.png" /> Unidades de Pronto Atendimento (UPA)'
            });
var format_UnidadesdeSade_6 = new ol.format.GeoJSON();
var features_UnidadesdeSade_6 = format_UnidadesdeSade_6.readFeatures(json_UnidadesdeSade_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_UnidadesdeSade_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_UnidadesdeSade_6.addFeatures(features_UnidadesdeSade_6);
var lyr_UnidadesdeSade_6 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_UnidadesdeSade_6, 
                style: style_UnidadesdeSade_6,
                popuplayertitle: 'Unidades de Saúde',
                interactive: true,
                title: '<img src="styles/legend/UnidadesdeSade_6.png" /> Unidades de Saúde'
            });
var format_DistritosSanitrios_7 = new ol.format.GeoJSON();
var features_DistritosSanitrios_7 = format_DistritosSanitrios_7.readFeatures(json_DistritosSanitrios_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_DistritosSanitrios_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_DistritosSanitrios_7.addFeatures(features_DistritosSanitrios_7);
var lyr_DistritosSanitrios_7 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_DistritosSanitrios_7, 
                style: style_DistritosSanitrios_7,
                popuplayertitle: 'Distritos Sanitários',
                interactive: false,
                title: '<img src="styles/legend/DistritosSanitrios_7.png" /> Distritos Sanitários'
            });
var format_FavelaseAglomeradosUrbanos_8 = new ol.format.GeoJSON();
var features_FavelaseAglomeradosUrbanos_8 = format_FavelaseAglomeradosUrbanos_8.readFeatures(json_FavelaseAglomeradosUrbanos_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_FavelaseAglomeradosUrbanos_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_FavelaseAglomeradosUrbanos_8.addFeatures(features_FavelaseAglomeradosUrbanos_8);
var lyr_FavelaseAglomeradosUrbanos_8 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_FavelaseAglomeradosUrbanos_8, 
                style: style_FavelaseAglomeradosUrbanos_8,
                popuplayertitle: 'Favelas e Aglomerados Urbanos',
                interactive: true,
                title: '<img src="styles/legend/FavelaseAglomeradosUrbanos_8.png" /> Favelas e Aglomerados Urbanos'
            });
var format_DivisadeBairros_9 = new ol.format.GeoJSON();
var features_DivisadeBairros_9 = format_DivisadeBairros_9.readFeatures(json_DivisadeBairros_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_DivisadeBairros_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_DivisadeBairros_9.addFeatures(features_DivisadeBairros_9);
var lyr_DivisadeBairros_9 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_DivisadeBairros_9, 
                style: style_DivisadeBairros_9,
                popuplayertitle: 'Divisa de Bairros',
                interactive: false,
                title: '<img src="styles/legend/DivisadeBairros_9.png" /> Divisa de Bairros'
            });
var format_Curitiba_10 = new ol.format.GeoJSON();
var features_Curitiba_10 = format_Curitiba_10.readFeatures(json_Curitiba_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:31982'});
var jsonSource_Curitiba_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Curitiba_10.addFeatures(features_Curitiba_10);
var lyr_Curitiba_10 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Curitiba_10, 
                style: style_Curitiba_10,
                popuplayertitle: 'Curitiba',
                interactive: false,
                title: '<img src="styles/legend/Curitiba_10.png" /> Curitiba'
            });

lyr_GoogleSatellite_0.setVisible(false);lyr_RegioMetropolitanadeCuritiba_1.setVisible(true);lyr_SetoresCensitriosdeCuritibaDensidadeHA_2.setVisible(false);lyr_SetoresCensitriosdeCuritiba_3.setVisible(true);lyr_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4.setVisible(true);lyr_UnidadesdeProntoAtendimentoUPA_5.setVisible(true);lyr_UnidadesdeSade_6.setVisible(true);lyr_DistritosSanitrios_7.setVisible(true);lyr_FavelaseAglomeradosUrbanos_8.setVisible(false);lyr_DivisadeBairros_9.setVisible(false);lyr_Curitiba_10.setVisible(false);
var layersList = [lyr_GoogleSatellite_0,lyr_RegioMetropolitanadeCuritiba_1,lyr_SetoresCensitriosdeCuritibaDensidadeHA_2,lyr_SetoresCensitriosdeCuritiba_3,lyr_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4,lyr_UnidadesdeProntoAtendimentoUPA_5,lyr_UnidadesdeSade_6,lyr_DistritosSanitrios_7,lyr_FavelaseAglomeradosUrbanos_8,lyr_DivisadeBairros_9,lyr_Curitiba_10];
lyr_RegioMetropolitanadeCuritiba_1.set('fieldAliases', {'CD_MUN': 'CD_MUN', 'NM_MUN': 'NM_MUN', 'CD_RGI': 'CD_RGI', 'NM_RGI': 'NM_RGI', 'CD_RGINT': 'CD_RGINT', 'NM_RGINT': 'NM_RGINT', 'CD_UF': 'CD_UF', 'NM_UF': 'NM_UF', 'SIGLA_UF': 'SIGLA_UF', 'CD_REGIAO': 'CD_REGIAO', 'NM_REGIAO': 'NM_REGIAO', 'SIGLA_RG': 'SIGLA_RG', 'CD_CONCURB': 'CD_CONCURB', 'NM_CONCURB': 'NM_CONCURB', 'AREA_KM2': 'AREA_KM2', '01': '01', });
lyr_SetoresCensitriosdeCuritibaDensidadeHA_2.set('fieldAliases', {'fid': 'fid', 'CD_SETOR': 'Código do Setor:', 'SITUACAO': 'SITUACAO', 'CD_SIT': 'CD_SIT', 'CD_TIPO': 'CD_TIPO', 'AREA_KM2': 'AREA_KM2', 'CD_REGIAO': 'CD_REGIAO', 'NM_REGIAO': 'NM_REGIAO', 'CD_UF': 'CD_UF', 'NM_UF': 'NM_UF', 'CD_MUN': 'CD_MUN', 'NM_MUN': 'NM_MUN', 'CD_DIST': 'CD_DIST', 'NM_DIST': 'Distrito:', 'CD_SUBDIST': 'CD_SUBDIST', 'NM_SUBDIST': 'Subdistrito:', 'CD_BAIRRO': 'CD_BAIRRO', 'NM_BAIRRO': 'Bairro:', 'CD_NU': 'CD_NU', 'NM_NU': 'NM_NU', 'CD_FCU': 'CD_FCU', 'NM_FCU': 'NM_FCU', 'CD_AGLOM': 'CD_AGLOM', 'NM_AGLOM': 'NM_AGLOM', 'CD_RGINT': 'CD_RGINT', 'NM_RGINT': 'NM_RGINT', 'CD_RGI': 'CD_RGI', 'NM_RGI': 'NM_RGI', 'CD_CONCURB': 'CD_CONCURB', 'NM_CONCURB': 'NM_CONCURB', 'v0001': 'v0001', 'v0002': 'v0002', 'v0003': 'v0003', 'v0004': 'v0004', 'v0005': 'v0005', 'v0006': 'v0006', 'v0007': 'v0007', 'OBJECTID': 'OBJECTID', 'cd_setor_2': 'cd_setor_2', 'nm_mun_2': 'nm_mun_2', 'nm_subdist_2': 'nm_subdist_2', 'nm_bairro_2': 'nm_bairro_2', 'pop_2025': 'pop_2025', 'st_area_sh': 'st_area_sh', 'CONTRATO': 'CONTRATO', 'NOME_US': 'Unidade de Saúde:', 'DISTRITO': 'Distrito:', 'CD_SETOR_US': 'CD_SETOR_US', 'PROP': 'PROP', 'Shape_Length': 'Shape_Length', 'Shape_Area': 'Shape_Area', 'PROP_POP_2025': 'População do Setor:', 'POP_0_4_2025': 'POP_0_4_2025', 'POP_5_9_2025': 'POP_5_9_2025', 'POP_10_14_2025': 'POP_10_14_2025', 'POP_15_19_2025': 'POP_15_19_2025', 'POP_20_24_2025': 'POP_20_24_2025', 'POP_25_29_2025': 'POP_25_29_2025', 'POP_30_39_2025': 'POP_30_39_2025', 'POP_40_49_2025': 'POP_40_49_2025', 'POP_50_59_2025': 'POP_50_59_2025', 'POP_60_69_2025': 'POP_60_69_2025', 'POP_ACIMA70_2025': 'POP_ACIMA70_2025', 'MASC_2025': 'MASC_2025', 'MASC_0_4_2025': 'MASC_0_4_2025', 'MASC_5_9_2025': 'MASC_5_9_2025', 'MASC_10_14_2025': 'MASC_10_14_2025', 'MASC_15_19_2025': 'MASC_15_19_2025', 'MASC_20_24_2025': 'MASC_20_24_2025', 'MASC_25_29_2025': 'MASC_25_29_2025', 'MASC_30_39_2025': 'MASC_30_39_2025', 'MASC_40_49_2025': 'MASC_40_49_2025', 'MASC_50_59_2025': 'MASC_50_59_2025', 'MASC_60_69_2025': 'MASC_60_69_2025', 'MASC_ACIMA70_2025': 'MASC_ACIMA70_2025', 'FEM_2025': 'FEM_2025', 'FEM_0_4_2025': 'FEM_0_4_2025', 'FEM_5_9_2025': 'FEM_5_9_2025', 'FEM_10_14_2025': 'FEM_10_14_2025', 'FEM_15_19_2025': 'FEM_15_19_2025', 'FEM_20_24_2025': 'FEM_20_24_2025', 'FEM_25_29_2025': 'FEM_25_29_2025', 'FEM_30_39_2025': 'FEM_30_39_2025', 'FEM_40_49_2025': 'FEM_40_49_2025', 'FEM_50_59_2025': 'FEM_50_59_2025', 'FEM_60_69_2025': 'FEM_60_69_2025', 'FEM_ACIMA70_2025': 'FEM_ACIMA70_2025', 'Renda_Setores_IBGE_Valor do rendimento nominal mediano mensal das pessoas responsáveis com rendimentos por domicílios particulares permanentes ocupados (V06006)': 'Renda_Setores_IBGE_Valor do rendimento nominal mediano mensal das pessoas responsáveis com rendimentos por domicílios particulares permanentes ocupados (V06006)', 'DENS_HA': 'Densidade (HA)', });
lyr_SetoresCensitriosdeCuritiba_3.set('fieldAliases', {'CD_SETOR': 'Código do Setor:', 'SITUACAO': 'SITUACAO', 'CD_SIT': 'CD_SIT', 'CD_TIPO': 'CD_TIPO', 'AREA_KM2': 'AREA_KM2', 'CD_REGIAO': 'CD_REGIAO', 'NM_REGIAO': 'NM_REGIAO', 'CD_UF': 'CD_UF', 'NM_UF': 'NM_UF', 'CD_MUN': 'CD_MUN', 'NM_MUN': 'NM_MUN', 'CD_DIST': 'CD_DIST', 'NM_DIST': 'Distrito:', 'CD_SUBDIST': 'CD_SUBDIST', 'NM_SUBDIST': 'NM_SUBDIST', 'CD_BAIRRO': 'CD_BAIRRO', 'NM_BAIRRO': 'Bairro:', 'CD_NU': 'CD_NU', 'NM_NU': 'NM_NU', 'CD_FCU': 'CD_FCU', 'NM_FCU': 'NM_FCU', 'CD_AGLOM': 'CD_AGLOM', 'NM_AGLOM': 'NM_AGLOM', 'CD_RGINT': 'CD_RGINT', 'NM_RGINT': 'NM_RGINT', 'CD_RGI': 'CD_RGI', 'NM_RGI': 'NM_RGI', 'CD_CONCURB': 'CD_CONCURB', 'NM_CONCURB': 'NM_CONCURB', 'v0001': 'v0001', 'v0002': 'v0002', 'v0003': 'v0003', 'v0004': 'v0004', 'v0005': 'v0005', 'v0006': 'v0006', 'v0007': 'v0007', });
lyr_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'US': 'US', 'DISTRITO': 'DISTRITO', 'CONTRATO': 'CONTRATO', 'NOME': 'NOME', 'DATA': 'DATA', 'FONTE': 'FONTE', 'SHAPE_AREA': 'SHAPE_AREA', 'SHAPE_LEN': 'SHAPE_LEN', });
lyr_UnidadesdeProntoAtendimentoUPA_5.set('fieldAliases', {'CD_EQUI': 'CD_EQUI', 'CD_LOCAL': 'CD_LOCAL', 'CD_TEMA': 'CD_TEMA', 'TEMA': 'TEMA', 'ID_EQUIP': 'ID_EQUIP', 'EQUIPAMENT': 'EQUIPAMENT', 'CD_TIPO_EQ': 'CD_TIPO_EQ', 'TIPO_EQUI': 'TIPO_EQUI', 'CD_DEP_ADM': 'CD_DEP_ADM', 'DEP_ADMIN': 'DEP_ADMIN', 'NOME_COMPL': 'Nome:', 'PRE_NOME': 'PRE_NOME', 'NOME': 'NOME', 'SIGLA_EQUI': 'SIGLA_EQUI', 'CONVENIADO': 'CONVENIADO', 'NOME_ABREV': 'NOME_ABREV', 'NOME_MAPA': 'NOME_MAPA', 'CD_RUA': 'CD_RUA', 'NOME_RUA': 'NOME_RUA', 'NOME_RUANO': 'NOME_RUANO', 'NUM_PRED': 'NUM_PRED', 'COMPL_END': 'COMPL_END', 'DIVULGAR_E': 'DIVULGAR_E', 'INDFISCAL': 'INDFISCAL', 'CD_BAIRRO': 'CD_BAIRRO', 'BAIRRO': 'BAIRRO', 'QUADR_EQUI': 'QUADR_EQUI', 'CD_REGIONA': 'CD_REGIONA', 'REGIONAL': 'REGIONAL', 'CD_DISTRIT': 'CD_DISTRIT', 'CD_EQUI_DI': 'CD_EQUI_DI', 'NM_DISTRIT': 'NM_DISTRIT', 'FUNC_MANHA': 'FUNC_MANHA', 'FUNC_TARDE': 'FUNC_TARDE', 'FUNC_NOITE': 'FUNC_NOITE', 'FUNC_24HR': 'FUNC_24HR', 'TELEFONE': 'TELEFONE', 'RAMAL': 'RAMAL', 'EMAIL': 'EMAIL', 'SITE': 'SITE', 'DT_INAUGUR': 'DT_INAUGUR', 'DT_ATUALIZ': 'DT_ATUALIZ', 'OBSERVACAO': 'OBSERVACAO', 'FONTE': 'FONTE', 'CD_MANTENE': 'CD_MANTENE', 'DS_MANTENE': 'DS_MANTENE', 'SIGLA_MANT': 'SIGLA_MANT', 'INATIVO_EQ': 'INATIVO_EQ', 'LAT_SIRGAS': 'LAT_SIRGAS', 'LON_SIRGAS': 'LON_SIRGAS', });
lyr_UnidadesdeSade_6.set('fieldAliases', {'CD_EQUI': 'CD_EQUI', 'CD_LOCAL': 'CD_LOCAL', 'CD_TEMA': 'CD_TEMA', 'TEMA': 'TEMA', 'ID_EQUIP': 'ID_EQUIP', 'EQUIPAMENT': 'EQUIPAMENT', 'CD_TIPO_EQ': 'CD_TIPO_EQ', 'TIPO_EQUI': 'TIPO_EQUI', 'CD_DEP_ADM': 'CD_DEP_ADM', 'DEP_ADMIN': 'DEP_ADMIN', 'NOME_COMPL': 'Nome:', 'PRE_NOME': 'PRE_NOME', 'NOME': 'NOME', 'SIGLA_EQUI': 'SIGLA_EQUI', 'CONVENIADO': 'CONVENIADO', 'NOME_ABREV': 'NOME_ABREV', 'NOME_MAPA': 'NOME_MAPA', 'CD_RUA': 'CD_RUA', 'NOME_RUA': 'NOME_RUA', 'NOME_RUANO': 'NOME_RUANO', 'NUM_PRED': 'NUM_PRED', 'COMPL_END': 'COMPL_END', 'DIVULGAR_E': 'DIVULGAR_E', 'INDFISCAL': 'INDFISCAL', 'CD_BAIRRO': 'CD_BAIRRO', 'BAIRRO': 'BAIRRO', 'QUADR_EQUI': 'QUADR_EQUI', 'CD_REGIONA': 'CD_REGIONA', 'REGIONAL': 'REGIONAL', 'CD_DISTRIT': 'CD_DISTRIT', 'CD_EQUI_DI': 'CD_EQUI_DI', 'NM_DISTRIT': 'NM_DISTRIT', 'FUNC_MANHA': 'FUNC_MANHA', 'FUNC_TARDE': 'FUNC_TARDE', 'FUNC_NOITE': 'FUNC_NOITE', 'FUNC_24HR': 'FUNC_24HR', 'TELEFONE': 'TELEFONE', 'RAMAL': 'RAMAL', 'EMAIL': 'EMAIL', 'SITE': 'SITE', 'DT_INAUGUR': 'DT_INAUGUR', 'DT_ATUALIZ': 'DT_ATUALIZ', 'OBSERVACAO': 'OBSERVACAO', 'FONTE': 'FONTE', 'CD_MANTENE': 'CD_MANTENE', 'DS_MANTENE': 'DS_MANTENE', 'SIGLA_MANT': 'SIGLA_MANT', 'INATIVO_EQ': 'INATIVO_EQ', 'LAT_SIRGAS': 'LAT_SIRGAS', 'LON_SIRGAS': 'LON_SIRGAS', });
lyr_DistritosSanitrios_7.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'DISTRITO': 'DISTRITO', 'COUNT': 'COUNT', 'DATA': 'DATA', 'FONTE': 'FONTE', 'SHAPE_AREA': 'SHAPE_AREA', 'SHAPE_LEN': 'SHAPE_LEN', });
lyr_FavelaseAglomeradosUrbanos_8.set('fieldAliases', {'cd_fcu': 'cd_fcu', 'nm_fcu': 'Nome:', 'cd_uf': 'cd_uf', 'nm_uf': 'nm_uf', 'sigla_uf': 'sigla_uf', 'cd_mun': 'cd_mun', 'nm_mun': 'nm_mun', });
lyr_DivisadeBairros_9.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'CODIGO': 'CODIGO', 'TIPO': 'TIPO', 'NOME': 'NOME', 'FONTE': 'FONTE', 'CD_REGIONA': 'CD_REGIONA', 'NM_REGIONA': 'NM_REGIONA', 'SHAPE_AREA': 'SHAPE_AREA', 'SHAPE_LEN': 'SHAPE_LEN', });
lyr_Curitiba_10.set('fieldAliases', {'CD_MUN': 'CD_MUN', 'NM_MUN': 'NM_MUN', 'CD_RGI': 'CD_RGI', 'NM_RGI': 'NM_RGI', 'CD_RGINT': 'CD_RGINT', 'NM_RGINT': 'NM_RGINT', 'CD_UF': 'CD_UF', 'NM_UF': 'NM_UF', 'SIGLA_UF': 'SIGLA_UF', 'CD_REGIAO': 'CD_REGIAO', 'NM_REGIAO': 'NM_REGIAO', 'SIGLA_RG': 'SIGLA_RG', 'CD_CONCURB': 'CD_CONCURB', 'NM_CONCURB': 'NM_CONCURB', 'AREA_KM2': 'AREA_KM2', '01': '01', });
lyr_RegioMetropolitanadeCuritiba_1.set('fieldImages', {'CD_MUN': 'TextEdit', 'NM_MUN': 'TextEdit', 'CD_RGI': 'TextEdit', 'NM_RGI': 'TextEdit', 'CD_RGINT': 'TextEdit', 'NM_RGINT': 'TextEdit', 'CD_UF': 'TextEdit', 'NM_UF': 'TextEdit', 'SIGLA_UF': 'TextEdit', 'CD_REGIAO': 'TextEdit', 'NM_REGIAO': 'TextEdit', 'SIGLA_RG': 'TextEdit', 'CD_CONCURB': 'TextEdit', 'NM_CONCURB': 'TextEdit', 'AREA_KM2': 'TextEdit', '01': 'TextEdit', });
lyr_SetoresCensitriosdeCuritibaDensidadeHA_2.set('fieldImages', {'fid': 'TextEdit', 'CD_SETOR': 'TextEdit', 'SITUACAO': 'TextEdit', 'CD_SIT': 'TextEdit', 'CD_TIPO': 'TextEdit', 'AREA_KM2': 'TextEdit', 'CD_REGIAO': 'TextEdit', 'NM_REGIAO': 'TextEdit', 'CD_UF': 'TextEdit', 'NM_UF': 'TextEdit', 'CD_MUN': 'TextEdit', 'NM_MUN': 'TextEdit', 'CD_DIST': 'TextEdit', 'NM_DIST': 'TextEdit', 'CD_SUBDIST': 'TextEdit', 'NM_SUBDIST': 'TextEdit', 'CD_BAIRRO': 'TextEdit', 'NM_BAIRRO': 'TextEdit', 'CD_NU': 'TextEdit', 'NM_NU': 'TextEdit', 'CD_FCU': 'TextEdit', 'NM_FCU': 'TextEdit', 'CD_AGLOM': 'TextEdit', 'NM_AGLOM': 'TextEdit', 'CD_RGINT': 'TextEdit', 'NM_RGINT': 'TextEdit', 'CD_RGI': 'TextEdit', 'NM_RGI': 'TextEdit', 'CD_CONCURB': 'TextEdit', 'NM_CONCURB': 'TextEdit', 'v0001': 'TextEdit', 'v0002': 'TextEdit', 'v0003': 'TextEdit', 'v0004': 'TextEdit', 'v0005': 'TextEdit', 'v0006': 'TextEdit', 'v0007': 'TextEdit', 'OBJECTID': 'Range', 'cd_setor_2': 'TextEdit', 'nm_mun_2': 'TextEdit', 'nm_subdist_2': 'TextEdit', 'nm_bairro_2': 'TextEdit', 'pop_2025': 'TextEdit', 'st_area_sh': 'TextEdit', 'CONTRATO': 'Range', 'NOME_US': 'TextEdit', 'DISTRITO': 'TextEdit', 'CD_SETOR_US': 'TextEdit', 'PROP': 'TextEdit', 'Shape_Length': 'TextEdit', 'Shape_Area': 'TextEdit', 'PROP_POP_2025': 'TextEdit', 'POP_0_4_2025': 'TextEdit', 'POP_5_9_2025': 'TextEdit', 'POP_10_14_2025': 'TextEdit', 'POP_15_19_2025': 'TextEdit', 'POP_20_24_2025': 'TextEdit', 'POP_25_29_2025': 'TextEdit', 'POP_30_39_2025': 'TextEdit', 'POP_40_49_2025': 'TextEdit', 'POP_50_59_2025': 'TextEdit', 'POP_60_69_2025': 'TextEdit', 'POP_ACIMA70_2025': 'TextEdit', 'MASC_2025': 'TextEdit', 'MASC_0_4_2025': 'TextEdit', 'MASC_5_9_2025': 'TextEdit', 'MASC_10_14_2025': 'TextEdit', 'MASC_15_19_2025': 'TextEdit', 'MASC_20_24_2025': 'TextEdit', 'MASC_25_29_2025': 'TextEdit', 'MASC_30_39_2025': 'TextEdit', 'MASC_40_49_2025': 'TextEdit', 'MASC_50_59_2025': 'TextEdit', 'MASC_60_69_2025': 'TextEdit', 'MASC_ACIMA70_2025': 'TextEdit', 'FEM_2025': 'TextEdit', 'FEM_0_4_2025': 'TextEdit', 'FEM_5_9_2025': 'TextEdit', 'FEM_10_14_2025': 'TextEdit', 'FEM_15_19_2025': 'TextEdit', 'FEM_20_24_2025': 'TextEdit', 'FEM_25_29_2025': 'TextEdit', 'FEM_30_39_2025': 'TextEdit', 'FEM_40_49_2025': 'TextEdit', 'FEM_50_59_2025': 'TextEdit', 'FEM_60_69_2025': 'TextEdit', 'FEM_ACIMA70_2025': 'TextEdit', 'Renda_Setores_IBGE_Valor do rendimento nominal mediano mensal das pessoas responsáveis com rendimentos por domicílios particulares permanentes ocupados (V06006)': 'Range', 'DENS_HA': 'TextEdit', });
lyr_SetoresCensitriosdeCuritiba_3.set('fieldImages', {'CD_SETOR': 'TextEdit', 'SITUACAO': 'TextEdit', 'CD_SIT': 'TextEdit', 'CD_TIPO': 'TextEdit', 'AREA_KM2': 'TextEdit', 'CD_REGIAO': 'TextEdit', 'NM_REGIAO': 'TextEdit', 'CD_UF': 'TextEdit', 'NM_UF': 'TextEdit', 'CD_MUN': 'TextEdit', 'NM_MUN': 'TextEdit', 'CD_DIST': 'TextEdit', 'NM_DIST': 'TextEdit', 'CD_SUBDIST': 'TextEdit', 'NM_SUBDIST': 'TextEdit', 'CD_BAIRRO': 'TextEdit', 'NM_BAIRRO': 'TextEdit', 'CD_NU': 'TextEdit', 'NM_NU': 'TextEdit', 'CD_FCU': 'TextEdit', 'NM_FCU': 'TextEdit', 'CD_AGLOM': 'TextEdit', 'NM_AGLOM': 'TextEdit', 'CD_RGINT': 'TextEdit', 'NM_RGINT': 'TextEdit', 'CD_RGI': 'TextEdit', 'NM_RGI': 'TextEdit', 'CD_CONCURB': 'TextEdit', 'NM_CONCURB': 'TextEdit', 'v0001': 'TextEdit', 'v0002': 'TextEdit', 'v0003': 'TextEdit', 'v0004': 'TextEdit', 'v0005': 'TextEdit', 'v0006': 'TextEdit', 'v0007': 'TextEdit', });
lyr_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4.set('fieldImages', {'OBJECTID': 'TextEdit', 'US': 'TextEdit', 'DISTRITO': 'TextEdit', 'CONTRATO': 'TextEdit', 'NOME': 'TextEdit', 'DATA': 'TextEdit', 'FONTE': 'TextEdit', 'SHAPE_AREA': 'TextEdit', 'SHAPE_LEN': 'TextEdit', });
lyr_UnidadesdeProntoAtendimentoUPA_5.set('fieldImages', {'CD_EQUI': 'TextEdit', 'CD_LOCAL': 'TextEdit', 'CD_TEMA': 'TextEdit', 'TEMA': 'TextEdit', 'ID_EQUIP': 'TextEdit', 'EQUIPAMENT': 'TextEdit', 'CD_TIPO_EQ': 'TextEdit', 'TIPO_EQUI': 'TextEdit', 'CD_DEP_ADM': 'TextEdit', 'DEP_ADMIN': 'TextEdit', 'NOME_COMPL': 'TextEdit', 'PRE_NOME': 'TextEdit', 'NOME': 'TextEdit', 'SIGLA_EQUI': 'TextEdit', 'CONVENIADO': 'TextEdit', 'NOME_ABREV': 'TextEdit', 'NOME_MAPA': 'TextEdit', 'CD_RUA': 'TextEdit', 'NOME_RUA': 'TextEdit', 'NOME_RUANO': 'TextEdit', 'NUM_PRED': 'TextEdit', 'COMPL_END': 'TextEdit', 'DIVULGAR_E': 'TextEdit', 'INDFISCAL': 'TextEdit', 'CD_BAIRRO': 'Range', 'BAIRRO': 'TextEdit', 'QUADR_EQUI': 'TextEdit', 'CD_REGIONA': 'Range', 'REGIONAL': 'TextEdit', 'CD_DISTRIT': 'TextEdit', 'CD_EQUI_DI': 'TextEdit', 'NM_DISTRIT': 'TextEdit', 'FUNC_MANHA': 'TextEdit', 'FUNC_TARDE': 'TextEdit', 'FUNC_NOITE': 'TextEdit', 'FUNC_24HR': 'TextEdit', 'TELEFONE': 'TextEdit', 'RAMAL': 'TextEdit', 'EMAIL': 'TextEdit', 'SITE': 'TextEdit', 'DT_INAUGUR': 'DateTime', 'DT_ATUALIZ': 'DateTime', 'OBSERVACAO': 'TextEdit', 'FONTE': 'TextEdit', 'CD_MANTENE': 'TextEdit', 'DS_MANTENE': 'TextEdit', 'SIGLA_MANT': 'TextEdit', 'INATIVO_EQ': 'TextEdit', 'LAT_SIRGAS': 'TextEdit', 'LON_SIRGAS': 'TextEdit', });
lyr_UnidadesdeSade_6.set('fieldImages', {'CD_EQUI': 'TextEdit', 'CD_LOCAL': 'TextEdit', 'CD_TEMA': 'TextEdit', 'TEMA': 'TextEdit', 'ID_EQUIP': 'TextEdit', 'EQUIPAMENT': 'TextEdit', 'CD_TIPO_EQ': 'TextEdit', 'TIPO_EQUI': 'TextEdit', 'CD_DEP_ADM': 'TextEdit', 'DEP_ADMIN': 'TextEdit', 'NOME_COMPL': 'TextEdit', 'PRE_NOME': 'TextEdit', 'NOME': 'TextEdit', 'SIGLA_EQUI': 'TextEdit', 'CONVENIADO': 'TextEdit', 'NOME_ABREV': 'TextEdit', 'NOME_MAPA': 'TextEdit', 'CD_RUA': 'TextEdit', 'NOME_RUA': 'TextEdit', 'NOME_RUANO': 'TextEdit', 'NUM_PRED': 'TextEdit', 'COMPL_END': 'TextEdit', 'DIVULGAR_E': 'TextEdit', 'INDFISCAL': 'TextEdit', 'CD_BAIRRO': 'Range', 'BAIRRO': 'TextEdit', 'QUADR_EQUI': 'TextEdit', 'CD_REGIONA': 'Range', 'REGIONAL': 'TextEdit', 'CD_DISTRIT': 'TextEdit', 'CD_EQUI_DI': 'TextEdit', 'NM_DISTRIT': 'TextEdit', 'FUNC_MANHA': 'TextEdit', 'FUNC_TARDE': 'TextEdit', 'FUNC_NOITE': 'TextEdit', 'FUNC_24HR': 'TextEdit', 'TELEFONE': 'TextEdit', 'RAMAL': 'TextEdit', 'EMAIL': 'TextEdit', 'SITE': 'TextEdit', 'DT_INAUGUR': 'DateTime', 'DT_ATUALIZ': 'DateTime', 'OBSERVACAO': 'TextEdit', 'FONTE': 'TextEdit', 'CD_MANTENE': 'TextEdit', 'DS_MANTENE': 'TextEdit', 'SIGLA_MANT': 'TextEdit', 'INATIVO_EQ': 'TextEdit', 'LAT_SIRGAS': 'TextEdit', 'LON_SIRGAS': 'TextEdit', });
lyr_DistritosSanitrios_7.set('fieldImages', {'OBJECTID': 'TextEdit', 'DISTRITO': 'TextEdit', 'COUNT': 'TextEdit', 'DATA': 'TextEdit', 'FONTE': 'TextEdit', 'SHAPE_AREA': 'TextEdit', 'SHAPE_LEN': 'TextEdit', });
lyr_FavelaseAglomeradosUrbanos_8.set('fieldImages', {'cd_fcu': 'TextEdit', 'nm_fcu': 'TextEdit', 'cd_uf': 'TextEdit', 'nm_uf': 'TextEdit', 'sigla_uf': 'TextEdit', 'cd_mun': 'TextEdit', 'nm_mun': 'TextEdit', });
lyr_DivisadeBairros_9.set('fieldImages', {'OBJECTID': 'TextEdit', 'CODIGO': 'TextEdit', 'TIPO': 'TextEdit', 'NOME': 'TextEdit', 'FONTE': 'TextEdit', 'CD_REGIONA': 'TextEdit', 'NM_REGIONA': 'TextEdit', 'SHAPE_AREA': 'TextEdit', 'SHAPE_LEN': 'TextEdit', });
lyr_Curitiba_10.set('fieldImages', {'CD_MUN': 'TextEdit', 'NM_MUN': 'TextEdit', 'CD_RGI': 'TextEdit', 'NM_RGI': 'TextEdit', 'CD_RGINT': 'TextEdit', 'NM_RGINT': 'TextEdit', 'CD_UF': 'TextEdit', 'NM_UF': 'TextEdit', 'SIGLA_UF': 'TextEdit', 'CD_REGIAO': 'TextEdit', 'NM_REGIAO': 'TextEdit', 'SIGLA_RG': 'TextEdit', 'CD_CONCURB': 'TextEdit', 'NM_CONCURB': 'TextEdit', 'AREA_KM2': 'TextEdit', '01': 'TextEdit', });
lyr_RegioMetropolitanadeCuritiba_1.set('fieldLabels', {'CD_MUN': 'no label', 'NM_MUN': 'no label', 'CD_RGI': 'no label', 'NM_RGI': 'no label', 'CD_RGINT': 'no label', 'NM_RGINT': 'no label', 'CD_UF': 'no label', 'NM_UF': 'no label', 'SIGLA_UF': 'no label', 'CD_REGIAO': 'no label', 'NM_REGIAO': 'no label', 'SIGLA_RG': 'no label', 'CD_CONCURB': 'no label', 'NM_CONCURB': 'no label', 'AREA_KM2': 'no label', '01': 'no label', });
lyr_SetoresCensitriosdeCuritibaDensidadeHA_2.set('fieldLabels', {'fid': 'hidden field', 'CD_SETOR': 'header label - always visible', 'SITUACAO': 'hidden field', 'CD_SIT': 'hidden field', 'CD_TIPO': 'hidden field', 'AREA_KM2': 'hidden field', 'CD_REGIAO': 'hidden field', 'NM_REGIAO': 'hidden field', 'CD_UF': 'hidden field', 'NM_UF': 'hidden field', 'CD_MUN': 'hidden field', 'NM_MUN': 'hidden field', 'CD_DIST': 'hidden field', 'NM_DIST': 'header label - always visible', 'CD_SUBDIST': 'hidden field', 'NM_SUBDIST': 'hidden field', 'CD_BAIRRO': 'hidden field', 'NM_BAIRRO': 'header label - always visible', 'CD_NU': 'hidden field', 'NM_NU': 'hidden field', 'CD_FCU': 'hidden field', 'NM_FCU': 'hidden field', 'CD_AGLOM': 'hidden field', 'NM_AGLOM': 'hidden field', 'CD_RGINT': 'hidden field', 'NM_RGINT': 'hidden field', 'CD_RGI': 'hidden field', 'NM_RGI': 'hidden field', 'CD_CONCURB': 'hidden field', 'NM_CONCURB': 'hidden field', 'v0001': 'hidden field', 'v0002': 'hidden field', 'v0003': 'hidden field', 'v0004': 'hidden field', 'v0005': 'hidden field', 'v0006': 'hidden field', 'v0007': 'hidden field', 'OBJECTID': 'hidden field', 'cd_setor_2': 'hidden field', 'nm_mun_2': 'hidden field', 'nm_subdist_2': 'hidden field', 'nm_bairro_2': 'hidden field', 'pop_2025': 'hidden field', 'st_area_sh': 'hidden field', 'CONTRATO': 'hidden field', 'NOME_US': 'hidden field', 'DISTRITO': 'hidden field', 'CD_SETOR_US': 'hidden field', 'PROP': 'hidden field', 'Shape_Length': 'hidden field', 'Shape_Area': 'hidden field', 'PROP_POP_2025': 'header label - always visible', 'POP_0_4_2025': 'hidden field', 'POP_5_9_2025': 'hidden field', 'POP_10_14_2025': 'hidden field', 'POP_15_19_2025': 'hidden field', 'POP_20_24_2025': 'hidden field', 'POP_25_29_2025': 'hidden field', 'POP_30_39_2025': 'hidden field', 'POP_40_49_2025': 'hidden field', 'POP_50_59_2025': 'hidden field', 'POP_60_69_2025': 'hidden field', 'POP_ACIMA70_2025': 'hidden field', 'MASC_2025': 'hidden field', 'MASC_0_4_2025': 'hidden field', 'MASC_5_9_2025': 'hidden field', 'MASC_10_14_2025': 'hidden field', 'MASC_15_19_2025': 'hidden field', 'MASC_20_24_2025': 'hidden field', 'MASC_25_29_2025': 'hidden field', 'MASC_30_39_2025': 'hidden field', 'MASC_40_49_2025': 'hidden field', 'MASC_50_59_2025': 'hidden field', 'MASC_60_69_2025': 'hidden field', 'MASC_ACIMA70_2025': 'hidden field', 'FEM_2025': 'hidden field', 'FEM_0_4_2025': 'hidden field', 'FEM_5_9_2025': 'hidden field', 'FEM_10_14_2025': 'hidden field', 'FEM_15_19_2025': 'hidden field', 'FEM_20_24_2025': 'hidden field', 'FEM_25_29_2025': 'hidden field', 'FEM_30_39_2025': 'hidden field', 'FEM_40_49_2025': 'hidden field', 'FEM_50_59_2025': 'hidden field', 'FEM_60_69_2025': 'hidden field', 'FEM_ACIMA70_2025': 'hidden field', 'Renda_Setores_IBGE_Valor do rendimento nominal mediano mensal das pessoas responsáveis com rendimentos por domicílios particulares permanentes ocupados (V06006)': 'hidden field', 'DENS_HA': 'header label - always visible', });
lyr_SetoresCensitriosdeCuritiba_3.set('fieldLabels', {'CD_SETOR': 'header label - always visible', 'SITUACAO': 'hidden field', 'CD_SIT': 'hidden field', 'CD_TIPO': 'hidden field', 'AREA_KM2': 'hidden field', 'CD_REGIAO': 'hidden field', 'NM_REGIAO': 'hidden field', 'CD_UF': 'hidden field', 'NM_UF': 'hidden field', 'CD_MUN': 'hidden field', 'NM_MUN': 'hidden field', 'CD_DIST': 'hidden field', 'NM_DIST': 'header label - always visible', 'CD_SUBDIST': 'hidden field', 'NM_SUBDIST': 'hidden field', 'CD_BAIRRO': 'hidden field', 'NM_BAIRRO': 'header label - always visible', 'CD_NU': 'hidden field', 'NM_NU': 'hidden field', 'CD_FCU': 'hidden field', 'NM_FCU': 'hidden field', 'CD_AGLOM': 'hidden field', 'NM_AGLOM': 'hidden field', 'CD_RGINT': 'hidden field', 'NM_RGINT': 'hidden field', 'CD_RGI': 'hidden field', 'NM_RGI': 'hidden field', 'CD_CONCURB': 'hidden field', 'NM_CONCURB': 'hidden field', 'v0001': 'hidden field', 'v0002': 'hidden field', 'v0003': 'hidden field', 'v0004': 'hidden field', 'v0005': 'hidden field', 'v0006': 'hidden field', 'v0007': 'hidden field', });
lyr_reasdeAbrangnciaUMSUnidadesMunicipaisdeSade_4.set('fieldLabels', {'OBJECTID': 'hidden field', 'US': 'hidden field', 'DISTRITO': 'hidden field', 'CONTRATO': 'hidden field', 'NOME': 'hidden field', 'DATA': 'hidden field', 'FONTE': 'hidden field', 'SHAPE_AREA': 'hidden field', 'SHAPE_LEN': 'hidden field', });
lyr_UnidadesdeProntoAtendimentoUPA_5.set('fieldLabels', {'CD_EQUI': 'hidden field', 'CD_LOCAL': 'hidden field', 'CD_TEMA': 'hidden field', 'TEMA': 'hidden field', 'ID_EQUIP': 'hidden field', 'EQUIPAMENT': 'hidden field', 'CD_TIPO_EQ': 'hidden field', 'TIPO_EQUI': 'hidden field', 'CD_DEP_ADM': 'hidden field', 'DEP_ADMIN': 'hidden field', 'NOME_COMPL': 'header label - always visible', 'PRE_NOME': 'hidden field', 'NOME': 'hidden field', 'SIGLA_EQUI': 'hidden field', 'CONVENIADO': 'hidden field', 'NOME_ABREV': 'hidden field', 'NOME_MAPA': 'hidden field', 'CD_RUA': 'hidden field', 'NOME_RUA': 'hidden field', 'NOME_RUANO': 'hidden field', 'NUM_PRED': 'hidden field', 'COMPL_END': 'hidden field', 'DIVULGAR_E': 'hidden field', 'INDFISCAL': 'hidden field', 'CD_BAIRRO': 'hidden field', 'BAIRRO': 'hidden field', 'QUADR_EQUI': 'hidden field', 'CD_REGIONA': 'hidden field', 'REGIONAL': 'hidden field', 'CD_DISTRIT': 'hidden field', 'CD_EQUI_DI': 'hidden field', 'NM_DISTRIT': 'hidden field', 'FUNC_MANHA': 'hidden field', 'FUNC_TARDE': 'hidden field', 'FUNC_NOITE': 'hidden field', 'FUNC_24HR': 'hidden field', 'TELEFONE': 'hidden field', 'RAMAL': 'hidden field', 'EMAIL': 'hidden field', 'SITE': 'hidden field', 'DT_INAUGUR': 'hidden field', 'DT_ATUALIZ': 'hidden field', 'OBSERVACAO': 'hidden field', 'FONTE': 'hidden field', 'CD_MANTENE': 'hidden field', 'DS_MANTENE': 'hidden field', 'SIGLA_MANT': 'hidden field', 'INATIVO_EQ': 'hidden field', 'LAT_SIRGAS': 'hidden field', 'LON_SIRGAS': 'hidden field', });
lyr_UnidadesdeSade_6.set('fieldLabels', {'CD_EQUI': 'hidden field', 'CD_LOCAL': 'hidden field', 'CD_TEMA': 'hidden field', 'TEMA': 'hidden field', 'ID_EQUIP': 'hidden field', 'EQUIPAMENT': 'hidden field', 'CD_TIPO_EQ': 'hidden field', 'TIPO_EQUI': 'hidden field', 'CD_DEP_ADM': 'hidden field', 'DEP_ADMIN': 'hidden field', 'NOME_COMPL': 'header label - always visible', 'PRE_NOME': 'hidden field', 'NOME': 'hidden field', 'SIGLA_EQUI': 'hidden field', 'CONVENIADO': 'hidden field', 'NOME_ABREV': 'hidden field', 'NOME_MAPA': 'hidden field', 'CD_RUA': 'hidden field', 'NOME_RUA': 'hidden field', 'NOME_RUANO': 'hidden field', 'NUM_PRED': 'hidden field', 'COMPL_END': 'hidden field', 'DIVULGAR_E': 'hidden field', 'INDFISCAL': 'hidden field', 'CD_BAIRRO': 'hidden field', 'BAIRRO': 'hidden field', 'QUADR_EQUI': 'hidden field', 'CD_REGIONA': 'hidden field', 'REGIONAL': 'hidden field', 'CD_DISTRIT': 'hidden field', 'CD_EQUI_DI': 'hidden field', 'NM_DISTRIT': 'hidden field', 'FUNC_MANHA': 'hidden field', 'FUNC_TARDE': 'hidden field', 'FUNC_NOITE': 'hidden field', 'FUNC_24HR': 'hidden field', 'TELEFONE': 'hidden field', 'RAMAL': 'hidden field', 'EMAIL': 'hidden field', 'SITE': 'hidden field', 'DT_INAUGUR': 'hidden field', 'DT_ATUALIZ': 'hidden field', 'OBSERVACAO': 'hidden field', 'FONTE': 'hidden field', 'CD_MANTENE': 'hidden field', 'DS_MANTENE': 'hidden field', 'SIGLA_MANT': 'hidden field', 'INATIVO_EQ': 'hidden field', 'LAT_SIRGAS': 'hidden field', 'LON_SIRGAS': 'hidden field', });
lyr_DistritosSanitrios_7.set('fieldLabels', {'OBJECTID': 'no label', 'DISTRITO': 'no label', 'COUNT': 'no label', 'DATA': 'no label', 'FONTE': 'no label', 'SHAPE_AREA': 'no label', 'SHAPE_LEN': 'no label', });
lyr_FavelaseAglomeradosUrbanos_8.set('fieldLabels', {'cd_fcu': 'hidden field', 'nm_fcu': 'header label - always visible', 'cd_uf': 'hidden field', 'nm_uf': 'hidden field', 'sigla_uf': 'hidden field', 'cd_mun': 'hidden field', 'nm_mun': 'hidden field', });
lyr_DivisadeBairros_9.set('fieldLabels', {'OBJECTID': 'no label', 'CODIGO': 'no label', 'TIPO': 'no label', 'NOME': 'no label', 'FONTE': 'no label', 'CD_REGIONA': 'no label', 'NM_REGIONA': 'no label', 'SHAPE_AREA': 'no label', 'SHAPE_LEN': 'no label', });
lyr_Curitiba_10.set('fieldLabels', {'CD_MUN': 'hidden field', 'NM_MUN': 'hidden field', 'CD_RGI': 'hidden field', 'NM_RGI': 'hidden field', 'CD_RGINT': 'hidden field', 'NM_RGINT': 'hidden field', 'CD_UF': 'hidden field', 'NM_UF': 'hidden field', 'SIGLA_UF': 'hidden field', 'CD_REGIAO': 'hidden field', 'NM_REGIAO': 'hidden field', 'SIGLA_RG': 'hidden field', 'CD_CONCURB': 'hidden field', 'NM_CONCURB': 'hidden field', 'AREA_KM2': 'hidden field', '01': 'hidden field', });
lyr_Curitiba_10.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});