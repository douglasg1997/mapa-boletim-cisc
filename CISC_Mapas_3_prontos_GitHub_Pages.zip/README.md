# Mapas temáticos — CISC Curitiba

Este repositório publica somente três mapas temáticos preparados a partir do projeto QGIS/qgis2web:

- [Áreas verdes](areas-verdes/)
- [Unidades administrativas](unidades-administrativas/)
- [Hidrografia](hidrografia/)

## Hospedagem

Em **Settings → Pages**, selecione **Deploy from a branch**, branch `main`, pasta `/(root)` e salve.

Endereço esperado: https://douglasg1997.github.io/mapa-boletim-cisc/

As camadas maiores estão em arquivos `.json.gz` e são descomprimidas no navegador para contornar o limite de upload por arquivo do GitHub Web e reduzir transferência. **Não remover os `.json.gz`.** O navegador precisa ser moderno e o site hospedado por HTTP(S).

As dependências de cada mapa estão dentro de sua respectiva pasta. Mantenha as pastas e os nomes.
